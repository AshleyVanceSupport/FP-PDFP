                            FinePrint Release Notes

                       ===== v11.44 March 11, 2024 =====

- fixed a bug that caused some embedded fonts in PDF files to be drawn as
  symbols

                       ===== v11.43 March 8, 2024 =====

- fixed a bug that sometimes caused incorrect text output when printing
  embedded fonts to a Postscript device

- fixed a bug that caused Windows to unnecessarily show the "How do you want
  to open this file?" dialog for FP and PDF files

- fixed a crash that sometimes happened when processing JPEG images

                       ===== v11.42 March 1, 2024 =====

- fixed a bug that caused incorrect results when pages were copied or moved

- fixed a bug that caused some embedded fonts in PDF files to be missing or
  drawn incorrectly

                       ===== v11.41 August 31, 2023 =====

- fixed a bug that caused vertical text to be displayed incorrectly

                       ===== v11.40 July 19, 2023 =====

- fixed a crash that sometimes occurred when editing printer settings in the
  Settings dialog

- bug fixes for the Server Edition Licensing tab

- when multiple servers are present, you can now change the Server Edition
  license server by right-clicking on the server in the Licensing tab server
  list

                       ===== v11.39 June 16, 2023 =====

- fixed a crash that occurred when working with some documents whose file
  names contain non-alphabetic characters

- fixed a crash that occurred when imaging some bitmaps

                       ===== v11.36 April 26, 2023 =====

                       ===== v11.35 March 29, 2023 =====

- fixed a bug that caused the Save As Text command to fail without creating
  any output

                      ===== v11.34 February 7, 2023 =====

- fixed bugs that caused CID-keyed fonts to crash or be rendered incorrectly

                      ===== v11.33 December 11, 2022 =====

- fixed a bug that caused incorrect text output when printing to Postscript
  printers

- fixed bugs that caused missing text when opening some PDF files

                      ===== v11.32 November 16, 2022 =====

- performance improvements

- fixed errors that sometimes happened when opening PDF files that use PDF
  functions

                      ===== v11.31 November 3, 2022 =====

- fixed a crash that sometimes happened when installing or uninstalling

- fixed a bug that sometimes caused Excel gridlines to be missing or printed
  incorrectly

                      ===== v11.30 October 24, 2022 =====

- fixed a bug that caused rotated text to be displayed incorrectly when
  selected

- fixed bugs that sometimes caused bitmaps to be displayed incorrectly when
  the Grayscale or Lighten settings are enabled

- fixed a bug that sometimes caused white fills to be ignored when opening PDF
  files

- highlighted text is now displayed correctly

- the Colors tab in the User Interface dialog now works correctly

                      ===== v11.29 October 13, 2022 =====

- installing or uninstalling no longer causes the Print Spooler service to be
  stopped and restarted

                      ===== v11.28 October 4, 2022 =====

- fixed a bug that caused incorrect text spacing when opening some PDF files

- performance improvements in the Server Edition Licensing tab

- fixed a bug in the Server Edition installer when installing onto a server
  with a previous version of the product already installed

                      ===== v11.27 September 9, 2022 =====

- fixed a bug that caused failures when requesting a Server Edition license

- fixed a bug that caused some bitmaps to be printed incorrectly to Postscript
  printers

- fixed a bug that caused failures in the Server Edition Licensing tab

                      ===== v11.25 September 1, 2022 =====

- fixed bugs that caused rotated text to be drawn incorrectly

- fixed bugs that caused long text strings to be drawn incorrectly

- fixed a crash that sometimes happened when selecting and deleting text

- performance improvements when opening large PDF files

                       ===== v11.22 August 17, 2022 =====

- fixed a bug that caused missing text when opening PDF files with widget
  annotations

- fixed a failure that sometimes happened when opening a large number of files
  from the Open dialog

- bug fixes for PDF files containing bitmaps that use non-RGB color spaces

- fixed a bug that caused failures when handling large numbers of incoming
  print jobs

- fixed a bug that sometimes caused thin gridlines to be missing

- fixed a bug that caused incorrect output when printing complex content to
  Postscript printers

- fixed errors when opening PDF files that use ICC-based color spaces

- fixed a bug that caused missing text when opening some PDF files

                        ===== v11.21 July 27, 2022 =====

- fixed bugs that caused errors with PDF files that use masked or transparent
  images

- fixed bugs that caused incorrect or missing text with PDF files that use
  TrueType or OpenType CFF fonts

- fixed a bug that caused a silent crash when opening some PDF files

- fixed a bug that caused incorrect images with PDF files that use JPEG2000
  compression

- improved rendering performance with documents that contain very complex line
  art

- PDF files that use indexed CalRGB bitmaps are now imaged correctly

                        ===== v11.20 July 5, 2022 =====

- fixed a bug that caused failures when opening PDF files that contain corrupt
  TrueType fonts

- usability improvements when adding, deleting, or changing items in list
  controls (e.g. the Jobs list, Notes list, etc)

- performance improvements when working with very large FP or PDF files

                        ===== v11.18 June 12, 2022 =====

- fixed bugs when rendering complex layered or masked content

                        ===== v11.17 June 5, 2022 =====

- fixed bugs that caused missing or incorrect output when rendering PDF
  patterns

- fixed bugs that caused incorrect text spacing when opening PDF files that
  use CID-keyed fonts

                        ===== v11.16 May 16, 2022 =====

- fixed bugs that caused missing or incorrect text output when opening PDF
  files

- fixed a crash when opening PDF files that contain CMYK bitmaps using
  JPEG2000 compression

- the FinePrint desktop icon is no longer recreated after being deleted

                        ===== v11.15 May 6, 2022 =====

- fixed a bug that caused failures when printing PDF files that contain
  corrupt TrueType fonts

- fixed a bug that caused missing output when opening PDF files that use
  complex transformations

- fixed a bug that caused uneven borders when printing tables from Word

- added support for the /Separation/DeviceGray color space when opening PDF
  files

                       ===== v11.12 March 19, 2022 =====

- PDF files that use JPEG2000 or JBIG2 compression are now opened correctly

- fixed a bug that caused pattern brushes to be displayed or printed
  incorrectly

- fixed a bug that caused pages to be incorrectly sized or cropped when
  opening PDF files

- fixed a GetFontData bug that sometimes happened when opening PDF files

                      ===== v11.11 March 8, 2022 =====

- improved Document Properties command (Ctrl+D, Settings\Document Properties,
  or double-click on a job in the Jobs list)

- fixed various bugs when imaging bitmaps from opened PDF files

- fixed a bug that caused failures when opening very large PDF files

- fixed a bug that caused an "Invalid file format" error when opening some PDF
  files

- fixed bugs that sometimes caused text in PDF files to be incorrectly spaced,
  rotated, or italicized

- fixed a bug that sometimes caused failures when opening PDF files that use
  OpenType CFF fonts with nonstandard encodings

- fixed a bug that prevented 32-bpp bitmaps from printing correctly

                      ===== v11.10 February 19, 2022 =====

- performance and quality improvements when imaging bitmaps

- PDF files that use CCITT Group 3 compression (e.g. full page scans) are now
  opened correctly

- fixed a crash that sometimes happened when opening PDF files that contain
  rotated pages

- fixed bugs that caused incorrect text output when opening PDF files that use
  complex text matrices

- fixed a bug that caused text in some PDF files to be incorrectly italicized

- fixed a bug that sometimes caused missing output when printing to FinePrint

- Zooming in and out now provides a finer level of control than before.
  This feature can be disabled by setting the following value in the registry:
    HKEY_CURRENT_USER\SOFTWARE\FinePrint Software\FinePrint11\CustomSettings\ClassicZoom=1

  If desired, fine zooming is also available in classic zoom mode by using the
  Ctrl+Alt + and Ctrl+Alt - key combinations.

- fixed a bug that sometimes caused incorrect results when dragging a JPEG
  bitmap onto the page display

- fixed a bug that caused the "Print this sheet" command to fail when printing
  individual sheets in Booklet layout

                      ===== v11.07 January 2, 2022 =====

- improved quality and performance when imaging bitmaps

                      ===== v11.06 December 6, 2021 =====

- the resizing control in thumbnail view now works correctly

- performance improvements when working with notes in complex documents

                      ===== v11.05 November 29, 2021 =====

- fixed a bug that caused missing text or blank pages when opening some PDF
  files

- fixed bugs that caused incorrect bitmap output when printing PDF files to
  other printers

- fixed a crash that sometimes happened when opening PDF files that contain
  CMYK bitmaps

- fixed a bug that caused failures when opening PDF files that use the Pattern
  color space

- fixed a bug that caused the Crop All command to hang or crash

- fixed a bug that caused opened PDF files to be overwritten as FP files

                      ===== v11.04 November 3, 2021 =====

- fixed a bug that sometimes caused incorrect results when printing embedded
  symbol fonts to other printers

- fixed a bug that caused unnecessary onscreen redrawing when printing to
  other printers

- fixed bugs that sometimes caused text output to be incorrectly bold or
  italic

- fixed a crash that sometimes happened when moving snapshotted content from
  one page to another

- fixed a bug that caused incorrect results with large paper sizes at high
  resolution

- fixed a bug that sometimes caused the Enlarge feature to produce incorrect
  results when opening PDF files that contain annotations

                      ===== v11.03 October 28, 2021 =====

- fixed a bug that sometimes caused failures or incorrect output when printing
  to physical printers

- fixed a bug that sometimes caused inverted black/white colors when opening
  PDF files that use CCITT compression

- fixed a bug that sometimes caused incorrect results when opening PDF files
  that use symbol fonts, e.g. musical notes

- the Enlarge feature in the Layout tab now works correctly when opening PDF
  files

                      ===== v11.02 October 21, 2021 =====

- minor edits to the Windows icons

- fixed a bug that caused redundant entries to appear in the Windows Explorer
  "Open With" list for FP files when multiple versions of FinePrint or
  pdfFactory are installed

- fixed a bug that caused GetFontData errors when opening PDF files that
  contain Japanese text

- fixed a bug that caused text in PDF files to be incorrectly spaced

- fixed a bug that sometimes caused a hang when cutting, copying, or deleting
  content in complex sessions

- fixed bugs that sometimes caused text in Type 1 fonts to be missing or
  incorrect when opening PDF files

- fixed bugs that sometimes caused missing or incorrect results when opening
  PDF files that use transparent images

- fixed a bug that caused failures when opening PDF files that use the
  /Separation /ICCBased /DeviceRGB color space

- when opening PDF files, the job name in the main window Jobs list is now set
  from the PDF file name instead of from the Document Properties title

                 ===== v11.01 October 10, 2021 =====

- new Windows icons for PDF files handled by FinePrint/pdfFactory

- bug fixes for bookmarks in PDF files

- fixed a bug that sometimes caused the installer to not recognize previously
  installed versions

                 ===== v11.0 October 3, 2021 =====

- initial version

                 ===== FreeImage =====

This software uses the FreeImage open source image library.
See http://freeimage.sourceforge.net for details.

FreeImage is used under the FreeImage Public License, version 1.0.
